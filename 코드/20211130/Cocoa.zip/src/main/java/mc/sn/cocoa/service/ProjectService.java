package mc.sn.cocoa.service;

import java.util.Map;

public interface ProjectService {
	public int addProject(Map projectMap);
}
