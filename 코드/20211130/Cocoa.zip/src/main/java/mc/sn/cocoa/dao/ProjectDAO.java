package mc.sn.cocoa.dao;

import java.util.Map;

public interface ProjectDAO {
	public int insertProject(Map projectMap);
}
