package mc.sn.cocoa.service;

import java.util.Map;

public interface CoachService {
	public int addNewCoach(Map coachMap) throws Exception;
}
