package mc.sn.cocoa.service;

import javax.servlet.http.HttpSession;

import mc.sn.cocoa.vo.MemberVO;

public interface MemberService {
	//회원 로그인 체크
	public boolean loginCheck(MemberVO vo, HttpSession session);
	//회원 로그인 정보
	public MemberVO viewMember(MemberVO vo);
	//회원 로그 아웃
	public void logout(HttpSession session);
}
