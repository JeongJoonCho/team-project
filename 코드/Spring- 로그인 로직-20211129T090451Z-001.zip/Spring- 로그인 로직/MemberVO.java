package mc.sn.cocoa.vo;

public class MemberVO {
	private String id;
	private String pwd;
	private String name;
	private String plmg;
	private String pContents;
	private String doLike;
	
	public MemberVO() {
		
	}

	public MemberVO(String id, String pwd, String name, String plmg, String pContents, String doLike) {
		super();
		this.id = id;
		this.pwd = pwd;
		this.name = name;
		this.plmg = plmg;
		this.pContents = pContents;
		this.doLike = doLike;
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPlmg() {
		return plmg;
	}

	public void setPlmg(String plmg) {
		this.plmg = plmg;
	}

	public String getpContents() {
		return pContents;
	}

	public void setpContents(String pContents) {
		this.pContents = pContents;
	}

	public String getDoLike() {
		return doLike;
	}

	public void setDoLike(String doLike) {
		this.doLike = doLike;
	}

	@Override
	public String toString() {
		return "MemberVO [id=" + id + ", pwd=" + pwd + ", name=" + name + ", plmg=" + plmg + ", pContents=" + pContents
				+ ", doLike=" + doLike + "]";
	}
	
}
