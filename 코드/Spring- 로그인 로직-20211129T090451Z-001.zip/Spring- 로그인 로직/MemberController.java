package mc.sn.cocoa.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import mc.sn.cocoa.service.MemberService;
import mc.sn.cocoa.vo.MemberVO;

@Controller
@RequestMapping("/service")
public class MemberController {
	private Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	@Autowired
	private MemberService memberService;
	
	@RequestMapping("/login.do")
	public String login() {
		
		
		return "service/login";
	}
	
	@RequestMapping(value="/logincheck.do", method=RequestMethod.POST)
	public ModelAndView loginCheck(@ModelAttribute MemberVO vo, HttpSession session) {
		boolean result = memberService.loginCheck(vo, session);
		ModelAndView mav = new ModelAndView();
		if(result == true) {//로그인 성공 , home.jsp로 이동
			mav.setViewName("home");
			mav.addObject("msg", "success");
			} else {//로그인 실패, login.jsp로 이동
				mav.setViewName("service/login");
				mav.addObject("msg", "failure");
				
			}
		return mav;
	}
		//로그아웃 처리
		@RequestMapping("logout.do")
		public ModelAndView logout(HttpSession session) {
			memberService.logout(session);
			ModelAndView mav = new ModelAndView();
			mav.setViewName("service/login");
			mav.addObject("msg","logout");
			return mav;
		}
		
		
		
		
	}

