package mc.sn.cocoa.service;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mc.sn.cocoa.dao.MemberDAO;
import mc.sn.cocoa.vo.MemberVO;

@Service
public class MemberServiceImpl implements MemberService{
	
	@Autowired
	private MemberDAO memberDAO;

	@Override
	public boolean loginCheck(MemberVO vo, HttpSession session) {
		boolean result = memberDAO.loginCheck(vo);
		if(result) {//true일 경우 세션에 등록
			MemberVO vo2 = viewMember(vo);//세션 변수 등록
			session.setAttribute("id", vo2.getId());
			session.setAttribute("name", vo2.getName());
		}
		return result;
	}
	//회원 로그인 정보
	@Override
	public MemberVO viewMember(MemberVO vo) {
		return memberDAO.viewMember(vo);
	}
	//회원 로그아웃
	@Override
	public void logout(HttpSession session) {
		//세션 변수 개별 삭제
		//session.removeAttribute("userId");
		//세션 정보를 초기화 시킴
		session.invalidate();
	}
}
