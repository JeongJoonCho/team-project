package mc.sn.cocoa.dao;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import mc.sn.cocoa.vo.MemberVO;

@Repository
public class MemberDAOImpl implements MemberDAO{
	//sqlSession 객체를 스프링에서 생성하여 주입
	//의존관계 주입(Dependency Injection), 느슨한 결합
	@Autowired
	private SqlSession sqlSession; // mybatis 실행객체
	
	//회원 로그인 체크
	@Override
	public boolean loginCheck(MemberVO vo) {
		String name = sqlSession.selectOne("loginCheck", vo);
		return(name == null) ? false : true;
	}
	//회원 로그아웃
	@Override
	public MemberVO viewMember(MemberVO vo) {
		return sqlSession.selectOne("viewMember", vo);
	}
	//회원 로그아웃
	@Override
	public void logout(HttpSession session) {
	}
}
